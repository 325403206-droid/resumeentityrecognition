"""
Annotated training data for Resume NER.

Each sample is a tuple of (text, {"entities": [(start, end, label)]}).
Labels:
    NAME             – Full name of the candidate
    EMAIL            – Email address
    PHONE            – Phone / mobile number
    SKILLS           – Technical or soft skills
    DEGREE           – Academic degree (B.Tech, MBA, etc.)
    COLLEGE          – Educational institution name
    DESIGNATION      – Job title / role
    COMPANY          – Employer / organisation name
    LOCATION         – City, state, or country
    GRADUATION_YEAR  – Year of graduation
"""

TRAINING_DATA = [
    # ---- Sample 1 ----
    (
        "Rahul Sharma\nEmail: rahul.sharma@gmail.com\nPhone: 9876543210\n"
        "Education: B.Tech in Computer Science from IIT Delhi, 2023\n"
        "Skills: Python, Machine Learning, Deep Learning, NLP\n"
        "Experience: Data Science Intern at Google, Bangalore",
        {
            "entities": [
                (0, 12, "NAME"),
                (20, 44, "EMAIL"),
                (52, 62, "PHONE"),
                (76, 81, "DEGREE"),
                (101, 110, "COLLEGE"),
                (112, 116, "GRADUATION_YEAR"),
                (125, 131, "SKILLS"),
                (133, 149, "SKILLS"),
                (151, 164, "SKILLS"),
                (166, 169, "SKILLS"),
                (183, 203, "DESIGNATION"),
                (207, 213, "COMPANY"),
                (215, 224, "LOCATION"),
            ]
        },
    ),
    # ---- Sample 2 ----
    (
        "Priya Patel\nEmail: priya.patel@yahoo.com\nPhone: 8765432109\n"
        "Education: M.Sc in Data Science from IISC Bangalore, 2024\n"
        "Skills: R, Statistics, Tableau, SQL\n"
        "Experience: Research Assistant at Microsoft, Hyderabad",
        {
            "entities": [
                (0, 11, "NAME"),
                (19, 41, "EMAIL"),
                (49, 59, "PHONE"),
                (73, 77, "DEGREE"),
                (95, 109, "COLLEGE"),
                (111, 115, "GRADUATION_YEAR"),
                (124, 125, "SKILLS"),
                (127, 137, "SKILLS"),
                (139, 146, "SKILLS"),
                (148, 151, "SKILLS"),
                (165, 185, "DESIGNATION"),
                (189, 198, "COMPANY"),
                (200, 209, "LOCATION"),
            ]
        },
    ),
    # ---- Sample 3 ----
    (
        "Amit Kumar\nEmail: amit.kumar@outlook.com\nPhone: 7654321098\n"
        "Education: B.E in Electronics from NIT Trichy, 2022\n"
        "Skills: C++, Embedded Systems, MATLAB, Arduino\n"
        "Experience: Hardware Engineer at Intel, Chennai",
        {
            "entities": [
                (0, 10, "NAME"),
                (18, 42, "EMAIL"),
                (50, 60, "PHONE"),
                (74, 77, "DEGREE"),
                (97, 107, "COLLEGE"),
                (109, 113, "GRADUATION_YEAR"),
                (122, 125, "SKILLS"),
                (127, 143, "SKILLS"),
                (145, 151, "SKILLS"),
                (153, 160, "SKILLS"),
                (174, 191, "DESIGNATION"),
                (195, 200, "COMPANY"),
                (202, 209, "LOCATION"),
            ]
        },
    ),
    # ---- Sample 4 ----
    (
        "Sneha Reddy\nEmail: sneha.reddy@gmail.com\nPhone: 6543210987\n"
        "Education: MBA in Marketing from IIM Ahmedabad, 2023\n"
        "Skills: Digital Marketing, SEO, Content Strategy, Google Analytics\n"
        "Experience: Marketing Analyst at Amazon, Mumbai",
        {
            "entities": [
                (0, 11, "NAME"),
                (19, 42, "EMAIL"),
                (50, 60, "PHONE"),
                (74, 77, "DEGREE"),
                (97, 111, "COLLEGE"),
                (113, 117, "GRADUATION_YEAR"),
                (126, 143, "SKILLS"),
                (145, 148, "SKILLS"),
                (150, 166, "SKILLS"),
                (168, 184, "SKILLS"),
                (198, 214, "DESIGNATION"),
                (218, 224, "COMPANY"),
                (226, 232, "LOCATION"),
            ]
        },
    ),
    # ---- Sample 5 ----
    (
        "Vikram Singh\nEmail: vikram.singh@hotmail.com\nPhone: 5432109876\n"
        "Education: B.Tech in Mechanical Engineering from BITS Pilani, 2021\n"
        "Skills: AutoCAD, SolidWorks, 3D Printing, Robotics\n"
        "Experience: Design Engineer at Tata Motors, Pune",
        {
            "entities": [
                (0, 12, "NAME"),
                (20, 46, "EMAIL"),
                (54, 64, "PHONE"),
                (78, 83, "DEGREE"),
                (111, 122, "COLLEGE"),
                (124, 128, "GRADUATION_YEAR"),
                (137, 144, "SKILLS"),
                (146, 156, "SKILLS"),
                (158, 169, "SKILLS"),
                (171, 179, "SKILLS"),
                (193, 208, "DESIGNATION"),
                (212, 223, "COMPANY"),
                (225, 229, "LOCATION"),
            ]
        },
    ),
    # ---- Sample 6 ----
    (
        "Ananya Gupta\nEmail: ananya.gupta@gmail.com\nPhone: 4321098765\n"
        "Education: B.Sc in Mathematics from St. Xavier's College Mumbai, 2022\n"
        "Skills: Python, Data Analysis, Pandas, NumPy\n"
        "Experience: Data Analyst at Infosys, Bangalore",
        {
            "entities": [
                (0, 12, "NAME"),
                (20, 44, "EMAIL"),
                (52, 62, "PHONE"),
                (76, 80, "DEGREE"),
                (100, 127, "COLLEGE"),
                (129, 133, "GRADUATION_YEAR"),
                (142, 148, "SKILLS"),
                (150, 163, "SKILLS"),
                (165, 171, "SKILLS"),
                (173, 178, "SKILLS"),
                (192, 204, "DESIGNATION"),
                (208, 215, "COMPANY"),
                (217, 226, "LOCATION"),
            ]
        },
    ),
    # ---- Sample 7 ----
    (
        "Karthik Nair\nEmail: karthik.nair@gmail.com\nPhone: 3210987654\n"
        "Education: M.Tech in AI from IIT Madras, 2024\n"
        "Skills: TensorFlow, PyTorch, Computer Vision, GANs\n"
        "Experience: ML Engineer at Flipkart, Bangalore",
        {
            "entities": [
                (0, 12, "NAME"),
                (20, 44, "EMAIL"),
                (52, 62, "PHONE"),
                (76, 82, "DEGREE"),
                (93, 103, "COLLEGE"),
                (105, 109, "GRADUATION_YEAR"),
                (118, 128, "SKILLS"),
                (130, 137, "SKILLS"),
                (139, 154, "SKILLS"),
                (156, 160, "SKILLS"),
                (174, 185, "DESIGNATION"),
                (189, 197, "COMPANY"),
                (199, 208, "LOCATION"),
            ]
        },
    ),
    # ---- Sample 8 ----
    (
        "Divya Menon\nEmail: divya.menon@yahoo.com\nPhone: 2109876543\n"
        "Education: BCA from Christ University Bangalore, 2021\n"
        "Skills: Java, Spring Boot, REST APIs, MySQL\n"
        "Experience: Backend Developer at Wipro, Hyderabad",
        {
            "entities": [
                (0, 11, "NAME"),
                (19, 41, "EMAIL"),
                (49, 59, "PHONE"),
                (73, 76, "DEGREE"),
                (82, 110, "COLLEGE"),
                (112, 116, "GRADUATION_YEAR"),
                (125, 129, "SKILLS"),
                (131, 142, "SKILLS"),
                (144, 153, "SKILLS"),
                (155, 160, "SKILLS"),
                (174, 191, "DESIGNATION"),
                (195, 200, "COMPANY"),
                (202, 211, "LOCATION"),
            ]
        },
    ),
    # ---- Sample 9 ----
    (
        "Rohan Joshi\nEmail: rohan.joshi@gmail.com\nPhone: 1098765432\n"
        "Education: B.Tech in IT from VIT Vellore, 2023\n"
        "Skills: JavaScript, React, Node.js, MongoDB\n"
        "Experience: Full Stack Developer at TCS, Noida",
        {
            "entities": [
                (0, 11, "NAME"),
                (19, 42, "EMAIL"),
                (50, 60, "PHONE"),
                (74, 79, "DEGREE"),
                (92, 103, "COLLEGE"),
                (105, 109, "GRADUATION_YEAR"),
                (118, 128, "SKILLS"),
                (130, 135, "SKILLS"),
                (137, 144, "SKILLS"),
                (146, 153, "SKILLS"),
                (167, 187, "DESIGNATION"),
                (191, 194, "COMPANY"),
                (196, 201, "LOCATION"),
            ]
        },
    ),
    # ---- Sample 10 ----
    (
        "Meera Iyer\nEmail: meera.iyer@outlook.com\nPhone: 9988776655\n"
        "Education: M.A in English Literature from JNU Delhi, 2022\n"
        "Skills: Content Writing, Editing, Proofreading, WordPress\n"
        "Experience: Content Writer at Byju's, Bangalore",
        {
            "entities": [
                (0, 10, "NAME"),
                (18, 42, "EMAIL"),
                (50, 60, "PHONE"),
                (74, 77, "DEGREE"),
                (101, 110, "COLLEGE"),
                (112, 116, "GRADUATION_YEAR"),
                (125, 140, "SKILLS"),
                (142, 149, "SKILLS"),
                (151, 163, "SKILLS"),
                (165, 174, "SKILLS"),
                (188, 202, "DESIGNATION"),
                (206, 212, "COMPANY"),
                (214, 223, "LOCATION"),
            ]
        },
    ),
    # ---- Sample 11 ----
    (
        "Aditya Verma\nEmail: aditya.verma@gmail.com\nPhone: 8877665544\n"
        "Education: B.Tech in CSE from DTU Delhi, 2024\n"
        "Skills: Python, Django, Flask, PostgreSQL\n"
        "Experience: Software Developer at Paytm, Noida",
        {
            "entities": [
                (0, 12, "NAME"),
                (20, 44, "EMAIL"),
                (52, 62, "PHONE"),
                (76, 81, "DEGREE"),
                (95, 104, "COLLEGE"),
                (106, 110, "GRADUATION_YEAR"),
                (119, 125, "SKILLS"),
                (127, 133, "SKILLS"),
                (135, 140, "SKILLS"),
                (142, 152, "SKILLS"),
                (166, 184, "DESIGNATION"),
                (188, 193, "COMPANY"),
                (195, 200, "LOCATION"),
            ]
        },
    ),
    # ---- Sample 12 ----
    (
        "Nisha Sharma\nEmail: nisha.sharma@gmail.com\nPhone: 7766554433\n"
        "Education: B.Sc in Physics from Miranda House Delhi, 2021\n"
        "Skills: MATLAB, LaTeX, Data Visualization, Excel\n"
        "Experience: Research Intern at ISRO, Ahmedabad",
        {
            "entities": [
                (0, 12, "NAME"),
                (20, 44, "EMAIL"),
                (52, 62, "PHONE"),
                (76, 80, "DEGREE"),
                (96, 117, "COLLEGE"),
                (119, 123, "GRADUATION_YEAR"),
                (132, 138, "SKILLS"),
                (140, 145, "SKILLS"),
                (147, 165, "SKILLS"),
                (167, 172, "SKILLS"),
                (186, 201, "DESIGNATION"),
                (205, 209, "COMPANY"),
                (211, 220, "LOCATION"),
            ]
        },
    ),
    # ---- Sample 13 ----
    (
        "Siddharth Rao\nEmail: siddharth.rao@gmail.com\nPhone: 6655443322\n"
        "Education: MCA from JNTU Hyderabad, 2023\n"
        "Skills: Android, Kotlin, Firebase, Git\n"
        "Experience: Mobile App Developer at Zomato, Gurugram",
        {
            "entities": [
                (0, 13, "NAME"),
                (21, 47, "EMAIL"),
                (55, 65, "PHONE"),
                (79, 82, "DEGREE"),
                (88, 103, "COLLEGE"),
                (105, 109, "GRADUATION_YEAR"),
                (118, 125, "SKILLS"),
                (127, 133, "SKILLS"),
                (135, 143, "SKILLS"),
                (145, 148, "SKILLS"),
                (162, 182, "DESIGNATION"),
                (186, 192, "COMPANY"),
                (194, 202, "LOCATION"),
            ]
        },
    ),
    # ---- Sample 14 ----
    (
        "Pooja Mishra\nEmail: pooja.mishra@gmail.com\nPhone: 5544332211\n"
        "Education: B.Com from SRCC Delhi, 2022\n"
        "Skills: Accounting, Tally, SAP, Financial Analysis\n"
        "Experience: Finance Intern at Deloitte, Mumbai",
        {
            "entities": [
                (0, 12, "NAME"),
                (20, 44, "EMAIL"),
                (52, 62, "PHONE"),
                (76, 81, "DEGREE"),
                (87, 97, "COLLEGE"),
                (99, 103, "GRADUATION_YEAR"),
                (112, 122, "SKILLS"),
                (124, 129, "SKILLS"),
                (131, 134, "SKILLS"),
                (136, 154, "SKILLS"),
                (168, 182, "DESIGNATION"),
                (186, 194, "COMPANY"),
                (196, 202, "LOCATION"),
            ]
        },
    ),
    # ---- Sample 15 ----
    (
        "Arjun Das\nEmail: arjun.das@gmail.com\nPhone: 4433221100\n"
        "Education: B.Tech in ECE from NIT Surathkal, 2024\n"
        "Skills: VHDL, Verilog, FPGA, Signal Processing\n"
        "Experience: VLSI Design Intern at Qualcomm, Bangalore",
        {
            "entities": [
                (0, 9, "NAME"),
                (17, 38, "EMAIL"),
                (46, 56, "PHONE"),
                (70, 75, "DEGREE"),
                (87, 101, "COLLEGE"),
                (103, 107, "GRADUATION_YEAR"),
                (116, 120, "SKILLS"),
                (122, 129, "SKILLS"),
                (131, 135, "SKILLS"),
                (137, 154, "SKILLS"),
                (168, 186, "DESIGNATION"),
                (190, 198, "COMPANY"),
                (200, 209, "LOCATION"),
            ]
        },
    ),
]
