"""
Color palette for each NER entity label.
Used by the Streamlit app and spacy.displacy for rendering.
"""

ENTITY_COLORS = {
    "NAME":             "#FF6B6B",   # coral red
    "EMAIL":            "#4ECDC4",   # teal
    "PHONE":            "#45B7D1",   # sky blue
    "SKILLS":           "#96CEB4",   # sage green
    "DEGREE":           "#FFEAA7",   # pastel yellow
    "COLLEGE":          "#DDA0DD",   # plum
    "DESIGNATION":      "#F0E68C",   # khaki gold
    "COMPANY":          "#87CEEB",   # light blue
    "LOCATION":         "#98D8C8",   # mint
    "GRADUATION_YEAR":  "#F7DC6F",   # sunflower
}
