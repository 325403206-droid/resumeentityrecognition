"""
Run NER predictions on raw resume text using the trained model.

Usage:
    python src/predict.py            # uses a built-in sample resume
    python src/predict.py --text "…" # provide your own text
"""

import os
import sys
import argparse

import spacy


# Default model location (relative to project root)
MODEL_DIR = os.path.join(os.path.dirname(__file__), "..", "model")

SAMPLE_RESUME = (
    "Ravi Shankar\n"
    "Email: ravi.shankar@gmail.com\n"
    "Phone: 9123456780\n"
    "Education: B.Tech in Computer Science from IIT Bombay, 2023\n"
    "Skills: Python, Machine Learning, NLP, TensorFlow\n"
    "Experience: AI Engineer at Microsoft, Hyderabad"
)


def load_model(model_dir: str = MODEL_DIR) -> spacy.language.Language:
    """Load the trained spaCy NER model from disk."""
    if not os.path.isdir(model_dir):
        print(f"❌ Model not found at {os.path.abspath(model_dir)}")
        print("   Run  python src/train.py  first to train the model.")
        sys.exit(1)
    return spacy.load(model_dir)


def predict(text: str, nlp: spacy.language.Language = None) -> list[dict]:
    """
    Extract named entities from *text*.

    Returns a list of dicts, each with keys: text, label, start, end.
    """
    if nlp is None:
        nlp = load_model()

    doc = nlp(text)
    entities = []
    for ent in doc.ents:
        entities.append(
            {
                "text": ent.text,
                "label": ent.label_,
                "start": ent.start_char,
                "end": ent.end_char,
            }
        )
    return entities


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Predict entities in resume text")
    parser.add_argument("--text", type=str, default=None, help="Resume text to analyse")
    parser.add_argument("--model", type=str, default=MODEL_DIR, help="Path to trained model")
    args = parser.parse_args()

    resume_text = args.text or SAMPLE_RESUME
    nlp_model = load_model(args.model)
    results = predict(resume_text, nlp_model)

    print("\n" + "=" * 60)
    print("RESUME NER — Extracted Entities")
    print("=" * 60)
    for ent in results:
        print(f"  {ent['label']:<20s}  →  {ent['text']}")
    print("=" * 60)
