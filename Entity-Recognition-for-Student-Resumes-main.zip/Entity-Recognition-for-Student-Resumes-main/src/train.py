"""
Train a custom spaCy NER model on resume data.

Usage:
    python src/train.py [--epochs 30] [--output model]
"""

import os
import sys
import random
import argparse
import warnings

import spacy
from spacy.training import Example

# ---------------------------------------------------------------------------
# Allow running from the project root:  python src/train.py
# ---------------------------------------------------------------------------
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from data.training_data import TRAINING_DATA

# Custom entity labels used in the project
LABELS = [
    "NAME",
    "EMAIL",
    "PHONE",
    "SKILLS",
    "DEGREE",
    "COLLEGE",
    "DESIGNATION",
    "COMPANY",
    "LOCATION",
    "GRADUATION_YEAR",
]


def train_model(epochs: int = 30, output_dir: str = "model"):
    """Train the NER model and save it to *output_dir*."""

    # Start from a blank English model
    nlp = spacy.blank("en")

    # Create the NER component and add it to the pipeline
    ner = nlp.add_pipe("ner", last=True)
    for label in LABELS:
        ner.add_label(label)

    # Prepare training examples
    train_examples = []
    for text, annotations in TRAINING_DATA:
        doc = nlp.make_doc(text)
        example = Example.from_dict(doc, annotations)
        train_examples.append(example)

    # ---------- Training loop ----------
    optimizer = nlp.begin_training()

    print(f"Training with {len(train_examples)} examples for {epochs} epochs …")
    for epoch in range(epochs):
        random.shuffle(train_examples)
        losses = {}
        for example in train_examples:
            nlp.update([example], sgd=optimizer, losses=losses)

        # Log every 5 epochs
        if (epoch + 1) % 5 == 0 or epoch == 0:
            print(f"  Epoch {epoch + 1:>3}/{epochs}  —  loss: {losses['ner']:.4f}")

    # ---------- Save the model ----------
    output_path = os.path.join(os.path.dirname(__file__), "..", output_dir)
    os.makedirs(output_path, exist_ok=True)
    nlp.to_disk(output_path)
    print(f"\n✅ Model saved to  {os.path.abspath(output_path)}")


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train Resume NER model")
    parser.add_argument("--epochs", type=int, default=30, help="Number of training epochs (default: 30)")
    parser.add_argument("--output", type=str, default="model", help="Output directory for the model (default: model)")
    args = parser.parse_args()

    # Suppress spaCy training warnings that are noisy but harmless
    warnings.filterwarnings("ignore", message=".*W095.*")
    warnings.filterwarnings("ignore", message=".*W093.*")

    train_model(epochs=args.epochs, output_dir=args.output)
